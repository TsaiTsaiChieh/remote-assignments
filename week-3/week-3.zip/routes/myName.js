const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
    const name = req.cookies.name;
    if (name) {
        res.render('myName', { name });
    }
    else {
        res.render('myName');
    }
});

router.post('/', (req, res) => {
    res.cookie('name', req.body.name);
    res.redirect('/myName');
});

router.post('/clear', (req, res) => {
    console.log('myName clear');
    res.clearCookie('name');
    res.redirect('/myName');
});


// router.post('/hello', (req, res) => {
//     res.cookie('username', req.body.username);
//     res.redirect('/');
// });

// router.post('/goodbye', (req, res) => {
//     res.clearCookie('username');
//     res.redirect('/hello');
// });


module.exports = router;