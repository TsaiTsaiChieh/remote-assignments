const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
    res.render('layout');
    //     const name = req.cookies.name;
    //     if (name) {
    //         console.log(name);
    //     }
    //     else {
    //         console.log('no');

    //     }
});

module.exports = router;